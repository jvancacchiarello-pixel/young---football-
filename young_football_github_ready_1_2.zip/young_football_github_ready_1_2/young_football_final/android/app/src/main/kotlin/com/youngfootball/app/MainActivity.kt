package com.youngfootball.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
