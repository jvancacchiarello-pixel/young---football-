import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  Stream<User?> get authChanges => _auth.authStateChanges();

  Future<void> register(String email, String password, String displayName) async {
    final cred = await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    await cred.user!.updateDisplayName(displayName.trim());
    await _db.collection('users').doc(cred.user!.uid).set({
      'displayName': displayName.trim(), 'email': email.trim(), 'xp': 0, 'level': 1,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
  Future<void> login(String email, String password) =>
      _auth.signInWithEmailAndPassword(email: email.trim(), password: password);
  Future<void> logout() => _auth.signOut();
}
