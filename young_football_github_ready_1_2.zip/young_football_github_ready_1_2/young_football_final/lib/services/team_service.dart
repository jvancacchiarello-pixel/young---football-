import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
class TeamService {
 final db=FirebaseFirestore.instance; final auth=FirebaseAuth.instance;
 Stream<QuerySnapshot<Map<String,dynamic>>> teams()=>db.collection('teams').orderBy('createdAt',descending:true).snapshots();
 Future<void> createTeam(String name) async { final u=auth.currentUser!; await db.collection('teams').add({'name':name.trim(),'ownerId':u.uid,'memberIds':[u.uid],'createdAt':FieldValue.serverTimestamp()}); }
 Stream<QuerySnapshot<Map<String,dynamic>>> messages(String teamId)=>db.collection('teams').doc(teamId).collection('messages').orderBy('createdAt').snapshots();
 Future<void> send(String teamId,String text) async { final u=auth.currentUser!; if(text.trim().isEmpty)return; await db.collection('teams').doc(teamId).collection('messages').add({'senderId':u.uid,'senderName':u.displayName??'Giocatore','text':text.trim(),'createdAt':FieldValue.serverTimestamp()}); }
}
