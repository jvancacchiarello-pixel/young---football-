import 'package:flutter/material.dart';
class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});
  @override Widget build(BuildContext context) => Column(children: [
    const Expanded(child: Center(child: Text('Chat del Team\nMessaggi, comunicazioni e avvisi', textAlign: TextAlign.center))),
    SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
      const Expanded(child: TextField(decoration: InputDecoration(hintText: 'Scrivi un messaggio...', border: OutlineInputBorder()))),
      IconButton(onPressed: () {}, icon: const Icon(Icons.send))
    ])))
  ]);
}
