import 'package:flutter/material.dart';
class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const CircleAvatar(radius: 48, child: Icon(Icons.sports_soccer, size: 50)),
    const SizedBox(height: 12),
    const Center(child: Text('Carta Calciatore', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
    const Center(child: Text('Crea il tuo profilo e fai crescere le tue statistiche')),
    const SizedBox(height: 18),
    _tile('Livello', '1', Icons.star), _tile('XP', '0 / 100', Icons.bolt),
    _tile('Allenamenti', '0', Icons.fitness_center), _tile('Badge', '0', Icons.workspace_premium),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.edit), label: const Text('Modifica profilo')),
  ]);
  Widget _tile(String t, String v, IconData i) => Card(child: ListTile(leading: Icon(i), title: Text(t), trailing: Text(v, style: const TextStyle(fontWeight: FontWeight.bold))));
}
