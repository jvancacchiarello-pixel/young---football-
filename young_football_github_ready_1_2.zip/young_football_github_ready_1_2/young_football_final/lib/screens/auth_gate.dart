import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'auth_screen.dart'; import 'home_screen.dart';
class AuthGate extends StatelessWidget { const AuthGate({super.key}); @override Widget build(BuildContext c)=>StreamBuilder<User?>(stream:FirebaseAuth.instance.authStateChanges(),builder:(c,s){if(s.connectionState==ConnectionState.waiting)return const Scaffold(body:Center(child:CircularProgressIndicator())); return s.data==null?const AuthScreen():const HomeScreen();}); }
