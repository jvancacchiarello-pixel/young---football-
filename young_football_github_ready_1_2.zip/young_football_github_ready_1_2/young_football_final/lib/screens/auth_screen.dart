import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class AuthScreen extends StatefulWidget { const AuthScreen({super.key}); @override State<AuthScreen> createState()=>_AuthScreenState(); }
class _AuthScreenState extends State<AuthScreen> {
  final name=TextEditingController(), email=TextEditingController(), pass=TextEditingController();
  bool register=false, busy=false; String? error;
  Future<void> submit() async { setState(()=>busy=true); try { if(register) { await AuthService().register(email.text,pass.text,name.text); } else { await AuthService().login(email.text,pass.text); } } catch(e){ setState(()=>error='Controlla email e password e riprova.'); } finally { if(mounted)setState(()=>busy=false); } }
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:420),child:Column(children:[
    const Icon(Icons.sports_soccer,size:72), const SizedBox(height:12), Text('Young Football',style:Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)), const SizedBox(height:28),
    if(register) TextField(controller:name,decoration:const InputDecoration(labelText:'Nome giocatore',border:OutlineInputBorder())), if(register) const SizedBox(height:12),
    TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())), const SizedBox(height:12),
    TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())), if(error!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.red))), const SizedBox(height:18),
    SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:submit,child:Text(busy?'Attendi...':register?'Crea account':'Accedi'))),
    TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'Hai già un account? Accedi':'Nuovo giocatore? Registrati')),
  ]))))));
}
