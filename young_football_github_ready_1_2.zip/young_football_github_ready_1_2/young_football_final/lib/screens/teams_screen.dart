import 'package:flutter/material.dart';
class TeamsScreen extends StatelessWidget {
  const TeamsScreen({super.key});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(16), child: Column(children: [
    const Icon(Icons.groups, size: 72), const Text('I tuoi Team', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('Crea una squadra, invita altri giocatori e condividi attività e risultati.', textAlign: TextAlign.center),
    const SizedBox(height: 20),
    FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: const Text('Crea Team')),
    OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.group_add), label: const Text('Entra con codice invito')),
  ]));
}
