import 'package:flutter/material.dart';
class ChallengesScreen extends StatelessWidget {
  const ChallengesScreen({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    Text('Sfide e allenamenti', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    Card(child: ListTile(leading: Icon(Icons.directions_run), title: Text('Completa un allenamento'), subtitle: Text('+20 XP'))),
    Card(child: ListTile(leading: Icon(Icons.sports_soccer), title: Text('Sfida tecnica'), subtitle: Text('+30 XP'))),
    Card(child: ListTile(leading: Icon(Icons.leaderboard), title: Text('Classifica Team'), subtitle: Text('Confronta i progressi'))),
  ]);
}
