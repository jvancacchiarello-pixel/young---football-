import 'package:flutter/material.dart';
import 'player_screen.dart';
import 'teams_screen.dart';
import 'chat_screen.dart';
import 'challenges_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final pages = const [PlayerScreen(), TeamsScreen(), ChatScreen(), ChallengesScreen()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Young Football'), centerTitle: true),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.person), label: 'Profilo'),
        NavigationDestination(icon: Icon(Icons.groups), label: 'Team'),
        NavigationDestination(icon: Icon(Icons.chat_bubble), label: 'Chat'),
        NavigationDestination(icon: Icon(Icons.emoji_events), label: 'Sfide'),
      ],
    ),
  );
}
