import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/auth_gate.dart';
Future<void> main() async { WidgetsFlutterBinding.ensureInitialized(); await Firebase.initializeApp(); runApp(const YoungFootballApp()); }
class YoungFootballApp extends StatelessWidget { const YoungFootballApp({super.key}); @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Young Football',theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF126B3A)),useMaterial3:true),home:const AuthGate()); }
